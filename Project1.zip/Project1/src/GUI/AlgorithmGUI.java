package GUI;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Random;

import Sorts.*;
import javafx.scene.control.RadioButton;

public class AlgorithmGUI {
    private JPanel BasePanel;
    private JPanel LeftPanel;
    private JPanel TopRight;
    private JPanel MiddleRight;
    private JPanel BottomRight;
    private JTextField WinningField;
    private JSlider ArraySizeSlider;
    private JButton InsertionButton;
    private JButton SelectionButton;
    private JButton QuickSortButton;
    private JButton MergeSortButton;
    private JButton HeapSortButton;
    private JButton RadixSortButton;
    private JButton createTheListButton;
    private JRadioButton inOrderRadioButton;
    private JRadioButton reverseOrderRadioButton;
    private JRadioButton almostOrderRadioButton;
    private JRadioButton randomOrderRadioButton;
    private JTextField ArraySizeField;
    private JTextField TimeField;
    private JTextField MovementsField;
    private JTextField ComparisonsField;
    private JTextField SortField;
    private JTextField DataField;
    private JTextField NField;
    private JTextField NotationField;
    private Integer[] ArrayData;
    private int[] ArrayData2 = null;
    Random rand = new Random();
    long insertionTime;
    long selectionTime;
    long quickTime;
    long mergeTime;
    long heapTime;
    long radixTime;
    long lowestTime = 99999;


    public AlgorithmGUI() {
        WinningField.setEditable(false);
        ArraySizeField.setEditable(false);
        NField.setEditable(false);
        DataField.setEditable(false);
        SortField.setEditable(false);
        ComparisonsField.setEditable(false);
        MovementsField.setEditable(false);
        TimeField.setEditable(false);
        NotationField.setEditable(false);


        ArraySizeSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent changeEvent) {
                int ArrayData = ArraySizeSlider.getValue();
                ArraySizeField.setText("" + ArrayData);
            }
        });
        createTheListButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                NField.setText("" + ArraySizeSlider.getValue());

                if (inOrderRadioButton.isSelected())
                {
                    ArrayData2 = GenerateList.InOrder(ArraySizeSlider.getValue());
                    DataField.setText("InOrder");
                    //System.out.print(Arrays.toString(ArrayData2));
                }
                else if (reverseOrderRadioButton.isSelected())
                {
                    ArrayData2 = GenerateList.ReverseOrder(ArraySizeSlider.getValue());
                    DataField.setText("ReverseOrder");
                    //System.out.print(Arrays.toString(ArrayData2));
                }
                else if (almostOrderRadioButton.isSelected())
                {
                    ArrayData2 = GenerateList.AlmostOrder(ArraySizeSlider.getValue());
                    DataField.setText("AlmostOrder");
                    //System.out.print(Arrays.toString(ArrayData2));
                }
                else if (randomOrderRadioButton.isSelected())
                {
                    ArrayData2 = GenerateList.RandomOrder(ArraySizeSlider.getValue());
                    DataField.setText("Random");
                    //System.out.print(Arrays.toString(ArrayData2));
                }
            }
        });

       InsertionButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if (!(ArrayData2 ==null)) {
                    int[] TempArray = new int [ArrayData2.length];
                    for (int i = 0; i < ArrayData2.length; i++)
                        TempArray[i] = ArrayData2 [i];
                    SortField.setText("Insertion Sort");
                    InsertionSort.ComparisonCount = 0;//Reset the Comparison Counter
                    InsertionSort.MovementCount = 0;//Reset the Comparison Counter
                    long time1 = System.currentTimeMillis();
                    InsertionSort.insertionSort(TempArray);
                    long time2 = System.currentTimeMillis();
                    ComparisonsField.setText("" + InsertionSort.ComparisonCount);
                    MovementsField.setText("" + InsertionSort.MovementCount);
                    insertionTime = (time2 - time1);
                    if (insertionTime < lowestTime)
                    {
                        lowestTime = insertionTime;
                        WinningField.setText("Insertion Sort with " + lowestTime + " ms");
                    }
                    WinningField.setVisible(true);
                    TimeField.setText("" + insertionTime + " milliseconds");
                    NotationField.setText("O(n^2)");
                    JOptionPane.showMessageDialog(null, "This is Insertion Sort where the time complexity on an average case is O(n^2).\n" +
                            "It works by removing an element through each iteration and sorts from left to right. \n" +
                            "This sort is usually good when the array is already sorted.");
                    //System.out.println("\nInsertion Sorted: " + Arrays.toString(ArrayData2));
                    //System.out.println("Total time: " + insertionTime); //Total time of sort
                }
            }
        });

        SelectionButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if (!(ArrayData2 ==null)) {
                    int[] TempArray = new int [ArrayData2.length];
                    for (int i = 0; i < ArrayData2.length; i++)
                        TempArray[i] = ArrayData2 [i];
                    SortField.setText("Selection Sort");
                    SelectionSort.ComparisonCount = 0; //Reset the Comparison Counter
                    SelectionSort.MovementCount = 0;//Reset the Comparison Counter
                    long time3 = System.currentTimeMillis();
                    SelectionSort.selectionSort(TempArray);
                    long time4 = System.currentTimeMillis();
                    ComparisonsField.setText("" + SelectionSort.ComparisonCount);
                    MovementsField.setText("" + SelectionSort.MovementCount);
                    selectionTime = (time4 - time3);
                    if (selectionTime < lowestTime)
                    {
                        lowestTime = selectionTime;
                        WinningField.setText("Selection Sort with " + lowestTime + " ms");
                    }
                    WinningField.setVisible(true);
                    TimeField.setText("" + selectionTime + " milliseconds");
                    NotationField.setText("O(n^2)");
                    JOptionPane.showMessageDialog(null, "This is Selection Sort where the time complexity on an average case is O(n^2).\n" +
                            "It works by repeatedly searching for the smallest element from the unsorted part of the array \n" +
                            "(starting from index 1) and placing it at the beginning.\n" +
                            "This sort is usually good for smaller arrays.");
                    //System.out.println("\nSelection Sorted: " + Arrays.toString(ArrayData2));
                    //System.out.println("Total time: " + selectionTime); //Total time of sort
                }
            }
        });

        QuickSortButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if (!(ArrayData2 ==null)) {
                    int[] TempArray = new int [ArrayData2.length];
                    for (int i = 0; i < ArrayData2.length; i++)
                        TempArray[i] = ArrayData2 [i];
                    SortField.setText("Quick Sort");
                    //"partitioning the elements and keeping track of the index of the smaller and larger elements"
                    QuickSort.ComparisonCount = 0; //Reset the Comparison Counter
                    QuickSort.MovementCount = 0;//Reset the Comparison Counter
                    long time5 = System.currentTimeMillis();
                    QuickSort.quickSort(TempArray);
                    long time6 = System.currentTimeMillis();
                    ComparisonsField.setText("" + QuickSort.ComparisonCount);
                    MovementsField.setText("" + QuickSort.MovementCount);
                    quickTime = (time6 - time5);
                    if (quickTime < lowestTime)
                    {
                        lowestTime = quickTime;
                        WinningField.setText("Quick Sort with " + lowestTime + " ms");
                    }
                    WinningField.setVisible(true);
                    TimeField.setText("" + quickTime + " milliseconds");
                    NotationField.setText("O(n log(n))");
                    JOptionPane.showMessageDialog(null, "This is Quick Sort where the time complexity on an average case is O(n log(n)).\n" +
                            "It works by finding a pivot element and splitting the current array and repeats this recursively for each sub-array. \n" +
                            "This sort is usually considered as the fastest sorting algorithm (on an avg. case) because it requires no additional storage space to perform.");
                    //System.out.println("\nQuick Sorted: " + Arrays.toString(ArrayData2));
                    //System.out.println("Total time: " + quickTime); //Total time of sort
                }
            }
        });
        MergeSortButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if (!(ArrayData2 == null)) {
                    int[] TempArray = new int [ArrayData2.length];
                    for (int i = 0; i < ArrayData2.length; i++)
                        TempArray[i] = ArrayData2 [i];
                    SortField.setText("Merge Sort");
                    MergeSort.ComparisonCount = 0; //Reset the Comparison Counter
                    MergeSort.MovementCount = 0;//Reset the Comparison Counter
                    long time7 = System.currentTimeMillis();
                    MergeSort.mergeSort(TempArray);
                    long time8 = System.currentTimeMillis();
                    ComparisonsField.setText("" + MergeSort.ComparisonCount);
                    MovementsField.setText("" + MergeSort.MovementCount);
                    mergeTime = (time8 - time7);
                    if (mergeTime < lowestTime)
                    {
                        lowestTime = mergeTime;
                        WinningField.setText("Merge Sort with " + lowestTime + " ms");
                    }
                    WinningField.setVisible(true);
                    TimeField.setText("" + mergeTime + " milliseconds");
                    NotationField.setText("O(n log(n))");
                    JOptionPane.showMessageDialog(null, "This is Merge Sort where the time complexity on an average case is O(n log(n)).\n" +
                            "It works by splitting the array into two sub-arrays until one element is left. \n" +
                            "This sort is usually considered as a fast sorting algorithm in cases of larger array sizes.");
                    //System.out.println("\nMerge Sorted: " + Arrays.toString(ArrayData2));
                    //System.out.println("Total time: " + mergeTime); //Total time of sort
                }
            }
        });
        HeapSortButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if (!(ArrayData2 == null)) {
                    ArrayData = new Integer[ArrayData2.length];
                    for (int i = 0; i < ArrayData2.length; i++)
                        ArrayData[i] = ArrayData2 [i];
                    SortField.setText("Heap Sort");
                    Heap.ComparisonCount = 0; //Reset the Comparison Counter
                    Heap.MovementCount = 0;//Reset the Comparison Counter
                    long time9 = System.currentTimeMillis();
                    HeapSort.heapSort(ArrayData);
                    long time10 = System.currentTimeMillis();
                    ComparisonsField.setText("" + Heap.ComparisonCount);
                    MovementsField.setText("" + Heap.MovementCount);
                    heapTime = (time10 - time9);
                    if (heapTime < lowestTime)
                    {
                        lowestTime = heapTime;
                        WinningField.setText("Heap Sort with " + lowestTime + " ms");
                    }
                    WinningField.setVisible(true);
                    TimeField.setText("" + heapTime + " milliseconds");
                    NotationField.setText("O(n log(n))");
                    JOptionPane.showMessageDialog(null, "This is Heap Sort where the time complexity on an average case is O(n log(n)).\n" +
                            "It works by finding the biggest element and placing it at the end and repeats this for the remaining elements. \n" +
                            "This sort is usually good for maintaining a particular ordering when you want to extract either minimum or maximum values.");
                    //System.out.println("\nHeap Sorted: " + Arrays.toString(ArrayData));
                    //System.out.println("Total time: " + heapTime); //Total time of sort
                }
            }
        });
         RadixSortButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if (!(ArrayData2 == null)) {
                    int[] TempArray = new int [ArrayData2.length];
                    for (int i = 0; i < ArrayData2.length; i++)
                        TempArray[i] = ArrayData2 [i];
                    SortField.setText("Radix Sort");
                    Radix.ComparisonCount = 0; //Reset the Comparison Counter
                    Radix.MovementCount = 0;//Reset the Comparison Counter
                    long time11 = System.currentTimeMillis();
                    Radix.radixsort(TempArray, TempArray.length);
                    long time12 = System.currentTimeMillis();
                    ComparisonsField.setText("" + Radix.ComparisonCount);
                    MovementsField.setText("" + Radix.MovementCount);
                    radixTime = (time12 - time11);
                    if (radixTime < lowestTime)
                    {
                        lowestTime = radixTime;
                        WinningField.setText("Radix Sort with " + lowestTime + " ms");
                    }
                    WinningField.setVisible(true);
                    TimeField.setText("" + radixTime + " milliseconds");
                    NotationField.setText("O(nk)");
                    JOptionPane.showMessageDialog(null, "This is Radix Sort where the time complexity on an average case is O(nk).\n" +
                            "It works by using integer keys and grouping them by individual digits that share the same significant \n" +
                            "position where k is the number of digits. \n" +
                            "This sort is usually good when the range of the array elements is less.");
                    //System.out.println("\nRadix Sorted: " + Arrays.toString(ArrayData2));
                    //System.out.println("Total time: " + radixTime); //Total time of sort
                }
            }
        });

         ButtonGroup R = new ButtonGroup();
            R.add(InsertionButton);
            R.add(SelectionButton);
            R.add(QuickSortButton);
            R.add(MergeSortButton);
            R.add(HeapSortButton);
            R.add(RadixSortButton);

        ButtonGroup G = new ButtonGroup();
            G.add(inOrderRadioButton);
            G.add(reverseOrderRadioButton);
            G.add(almostOrderRadioButton);
            G.add(randomOrderRadioButton);

    }

        public static void main (String[]args)
        {
            JFrame i = new JFrame("Project1"); //creating instance of JFrame
            i.setContentPane(new AlgorithmGUI().BasePanel);

            i.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            i.pack();
            i.setSize(550, 475);
            i.setLayout(null);
            i.setVisible(true);
        }
    }
