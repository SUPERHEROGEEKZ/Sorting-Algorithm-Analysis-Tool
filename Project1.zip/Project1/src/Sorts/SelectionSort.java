package Sorts;

public class SelectionSort
{
    public static int ComparisonCount;
    public static int MovementCount;

    /**
     * The method for sorting the numbers
     */
    public static void selectionSort(int[] list) //change int[] to double[]
    {

        for (int i = 0; i < list.length - 1; i++)
        {
            //find minimum in the list[i...list.length-1]
            double currentMin = list[i];
            ;
            int currentMinIndex = i;

            for (int j = i + 1; j < list.length; j++)
            {
                ComparisonCount++;
                if (currentMin > list[j])
                {
                    currentMin = list[j];
                    currentMinIndex = j;
                }
            }

            //swap list[i] with list[currentMinIndex] if necessary

            if (currentMinIndex != i)
            {
                MovementCount++;
                list[currentMinIndex] = list[i];
                MovementCount++;
                list[i] = (int) currentMin; //delete (int)

            }
        }
    }
}
