package Sorts;
import java.util.Random;
import java.lang.reflect.Array;

public class GenerateList {
    private static int initialValues = 1;
    private static Random rand = new Random();

    public static int[] InOrder(int ArraySize) {
        int[] GeneratedArray = new int[ArraySize];
        for (int i = 0; i < ArraySize; i++)
            GeneratedArray[i] = i * initialValues;
        return GeneratedArray;
    }

    public static int[] ReverseOrder(int ArraySize) {
        int[] GeneratedArray = new int[ArraySize];
        for (int i = 0; i < ArraySize; i++)
            GeneratedArray[ArraySize - i - 1] = i * initialValues;
        return GeneratedArray;
    }

    public static int[] AlmostOrder(int ArraySize) {

        int[] GeneratedArray = new int[ArraySize];
        int end = (int)(0.80*ArraySize);
        for (int i = 0; i < end; i++)
            GeneratedArray[i] = i * initialValues;
        for (int i = end; i < ArraySize; i++)
            GeneratedArray[i] = rand.nextInt(100000);

        /*for (int i = 0; i < ArraySize; i++)
            GeneratedArray[i] = i * initialValues;
        int Reorder = (int) (ArraySize / (Math.floor(Math.random() * 13))); //15
        int IndexA = 0, IndexB = 0;
        for (int i = 0; i < Reorder; i++) {
            IndexA = (int) Math.floor(Math.random() * ArraySize);
            IndexB = (int) Math.floor(Math.random() * ArraySize);
            ChangeArray(GeneratedArray, IndexA, IndexB);
        }
        */
        return GeneratedArray;

    }

    public static int[] RandomOrder(int ArraySize) {

        int[] GeneratedArray = new int[ArraySize];
        int end = (int)(0.20*ArraySize);
        for (int i = 0; i < end; i++)
            GeneratedArray[i] = i * initialValues;
        for (int i = end; i < ArraySize; i++)
            GeneratedArray[i] = rand.nextInt(100000);

       /* int Index = 0;
        for (int i = 0; i < ArraySize; i++)
            GeneratedArray[i] = i * initialValues;
        for (int i = 0; i < ArraySize * 2; i++) {
            Index = (int) Math.floor(Math.random() * ArraySize);
            ChangeArray(GeneratedArray, i % ArraySize, Index);
        }

        */
        return GeneratedArray;
    }

    public static void ChangeArray(int array[], int i, int j) {
        int swap = array[i];
        array[i] = array[j];
        array[j] = swap;
    }
}