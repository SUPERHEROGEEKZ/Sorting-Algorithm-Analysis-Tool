package Sorts;

public class QuickSort
{
    public static int ComparisonCount;
    public static int MovementCount;

    public static void quickSort(int[] list)
    {

        quickSort(list, 0, list.length - 1);

    }

    public static void quickSort(int[] list, int first, int last)
    {
        if (last > first)
        {
            int pivotIndex = partition(list, first, last);
            quickSort(list, first, pivotIndex - 1);
            quickSort(list, pivotIndex + 1, last);
        }
    }

    /**
     * partition the array list[first...last]
     */
    public static int partition(int[] list, int first, int last)
    {
        int pivot = list[(first+last)/2]; //Choose the first element as the pivot
        int low = first + 1; //index for forward search
        int high = last; //Index for backward search

        while (high > low)
        {
            //search forward from left
            ComparisonCount++;
            while (low <= high && list[low] <= pivot)
            {

                low++;
            }

            //search backward from right
            ComparisonCount++;
            while (low <= high && list[high] > pivot)
            {
                high--;
            }

            //swap two elements in the list
            if (high > low)
            {
                int temp = list[high];
                MovementCount++;
                list[high] = list[low];
                MovementCount++;
                list[low] = temp;
            }
        }
        ComparisonCount++;
        while (high > first && list[high] >= pivot)
        {
            high--;
        }
        ComparisonCount++;
        //swap pivot with list[high]
        if (pivot > list[high])
        {
            MovementCount++;
            list[first] = list[high];
            MovementCount++;
            list[high] = pivot;
            return high;
        }
        else
            {
            return first;
        }
    }
}
