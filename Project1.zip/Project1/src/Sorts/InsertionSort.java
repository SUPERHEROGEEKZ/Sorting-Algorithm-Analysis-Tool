package Sorts;

public class InsertionSort
{
 public static int ComparisonCount;
 public static int MovementCount;
    /**
     * method for sorting numbers
     **/
    public static void insertionSort(int[] list)
    {

        for (int i = 1; i < list.length; i++)
        {
            /**Insert list[i] into a sorted sublist list[0..i-1] so that
             list [0..i] is sorted. **/
            int currentElement = list[i];
            int k;
            boolean MaybeComparison = false;
            for (k = i - 1; k >= 0 && list[k] > currentElement; k--)
            {
                MaybeComparison = true;
                ComparisonCount++;
                MovementCount++;
                list[k + 1] = list[k];
            }
            if (!MaybeComparison)
            {
                ComparisonCount++;
            }

            //Insert the current element into list[k+1]
            if (!(k+1 == i)) {
                MovementCount++;
            }
            list[k + 1] = currentElement;
        }

    }
}
